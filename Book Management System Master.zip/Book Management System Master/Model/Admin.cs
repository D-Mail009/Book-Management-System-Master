﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    public class Admin
    {
        //
        public string LoginId { get; set; }
        public string LoginPwd { get; set; }
        public string LoginType { get; set; }
        public string LoginRemark { get; set; }


    }
}
