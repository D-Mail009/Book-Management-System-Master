create database Library
go

use Library
go

-- �������ṹ
create table dbo.Department(
    DepartmentId int identity(1,1) not null primary key,
    DepartmentName nvarchar(50) not null
)
go

create table dbo.Class(
    ClassId int identity(1,1) not null primary key,
    ClassName nvarchar(50) not null
)
go

create table dbo.BookType(
    BookTypeId int identity(1,1) not null primary key,
    BookTypeName nvarchar(50) not null
)
go

create table dbo.BookInfo(
    BookId nvarchar(50) not null primary key,
    BookName nvarchar(50) not null,
    TimeIn datetime not null,
    BookTypeId int not null,
    Author nvarchar(50) null,
    PinYinCode nvarchar(50) null,
    Translator nvarchar(50) null,
    Language nvarchar(50) null,
    BookNumber nvarchar(50) null,
    Price nvarchar(50) null,
    Layout nvarchar(50) null,
    Address nvarchar(50) null,
    ISBS nvarchar(50) null,
    Versions nvarchar(50) null,
    BookRemark nvarchar(200) null
)
go

create table dbo.Admin(
    LoginId nvarchar(50) not null primary key,
    LoginPwd nvarchar(50) not null,
    LoginType nvarchar(50) not null,
    LoginRemark nvarchar(50) null
)
go

create table dbo.ReaderType(
    ReaderTypeId int identity(1,1) not null primary key,
    ReaderTypeName nvarchar(50) not null
)
go

create table dbo.Reader(
    ReaderId nvarchar(50) not null primary key,
    ReaderName nvarchar(50) not null,
    TimeIn datetime not null,
    TimeOut datetime not null,
    ReaderTypeId int not null,
    DepartmentId int null,
    ClassId int null,
    IdentityCard nvarchar(50) null,
    Gender nvarchar(50) null,
    Special nvarchar(50) null,
    Phone nvarchar(50) null,
    Email nvarchar(50) null,
    Address nvarchar(50) null,
    ReaderRemark nvarchar(200) null
)
go

create table dbo.BorrowReturn(
    BorrowId int identity(1,1) not null primary key,
    BookId nvarchar(50) not null,
    ReaderId nvarchar(50) not null,
    BorrowTime datetime not null,
    ReturnTime datetime not null,
    FactReturnTime datetime null,
    Fine decimal(18, 0) not null,
    RenewCount int not null,
    BorrowRemark nvarchar(50) null
)
go

-- �����ʼ����
set identity_insert Department on
insert Department (DepartmentId, DepartmentName) values
(1, N'�ƾ�ϵ'), (2, N'����ϵ'), (3, N'�����ϵ'), (4, N'����ϵ'), (5, N'Ӣ��ϵ')
set identity_insert Department off
go

set identity_insert Class on
insert Class (ClassId, ClassName) values
(1, N'�ƾ�����'), (2, N'���ն���'), (3, N'�����Ѱ�'),
(4, N'�����һ��'), (5, N'����һ��'), (6, N'��۶���')
set identity_insert Class off
go

set identity_insert BookType on
insert BookType (BookTypeId, BookTypeName) values
(1, N'Data'), (2, N'LOL'), (3, N'�Ż���'), (4, N'��ѧ'),
(5, N'��ѧ'), (6, N'����'), (7, N'����'), (8, N'��ѧ'),
(9, N'����С˵��'), (10, N'����'), (11, N'ҽѧ'),
(12, N'�׶�'), (13, N'����')
set identity_insert BookType off
go

insert BookInfo (BookId, BookName, TimeIn, BookTypeId, Author, PinYinCode, Translator, Language, BookNumber, Price, Layout, Address, ISBS, Versions, BookRemark) values

(N'TU��00000051', N'C#��̱���', cast(0x0000A6780102A853 as datetime), 1, N'��ΰ', N'CSharpBianChengBaoDian', N'��ΰ', N'����', N'978-7-15001', N'79.00', N'ƽװ��', N'����', N'978-7-15001', N'�����', N'C#���������ʵսָ��'),
(N'TU��00000001', N'���ݿ�ϵͳ����', cast(0x0000A67500F098E4 as datetime), 1, N'��ɺ', N'shujukuxitonggainian', N'���', N'����', N'978-7-11001', N'89.00', N'��װ��', N'����', N'978-7-11001', N'��һ��', N'���ݿ�ϵͳ����̲�'),
(N'TU��00000002', N'C#�߼����', cast(0x0000A67500F098E4 as datetime), 1, N'���', N'CSharpGaoJiBianCheng', N'�ŷ���', N'����', N'978-7-11002', N'95.00', N'ƽװ��', N'����', N'978-7-11002', N'�ڶ���', N'C#�߼���̼���')
go

insert Admin (LoginId, LoginPwd, LoginType, LoginRemark) values
(N'123456', N'123456', N'��ͨ����Ա', N'123456'),
(N'aaaaa', N'aaaaa', N'��ͨ����Ա', N''),
(N'admin', N'admin', N'��������Ա', N'����ɾ��')
go

set identity_insert ReaderType on
insert ReaderType (ReaderTypeId, ReaderTypeName) values
(1, N'��ʦ'), (2, N'����'), (3, N'ѧ��'), (4, N'Ա��')
set identity_insert ReaderType off
go

insert Reader (ReaderId, ReaderName, TimeIn, TimeOut, ReaderTypeId, DepartmentId, ClassId, IdentityCard, Gender, Special, Phone, Email, Address, ReaderRemark) values
(N'st-0000001', N'��С��', cast(0x0000A67901664D30 as datetime), cast(0x0000A84301664D00 as datetime), 3, 3, 4, N'430426200001014586', N'��', N'', N'13912345678', N'wangxiaoming@student.edu.cn', N'����ʡ��ɳ����´��', N'�����ϵ����ѧ��'),
(N'js-00000001', N'��˼', cast(0x0000A67500F098EA as datetime), cast(0x0000A67500F098EA as datetime), 1, 1, 1, N'510102199001010014', N'��', N'0833-2110001', N'13800138001', N'��˼@university.edu.cn', N'�����к�����ѧԺ·1��', N'�˲�'),
(N'js-00000002', N'����', cast(0x0000A67500F098EA as datetime), cast(0x0000A67500F098EA as datetime), 1, 1, 1, N'510102199001010015', N'��', N'0833-2110001', N'13800138002', N'����@university.edu.cn', N'�����к�����ѧԺ·2��', N'�˲�')
go

-- �����洢����
create procedure proc_addDepartment
    @DepartmentId int output,
    @DepartmentName nvarchar(50)
as
begin
    insert into Department (DepartmentName) values (@DepartmentName)
    set @DepartmentId = scope_identity()
end
go

create procedure proc_addClass
    @ClassId int output,
    @ClassName nvarchar(50)
as
begin
    insert into Class (ClassName) values (@ClassName)
    set @ClassId = scope_identity()
end
go

create procedure proc_AddBookTypeInfo
    @BookTypeId int output,
    @BookTypeName nvarchar(50)
as
begin
    insert into BookType (BookTypeName) values (@BookTypeName)
    set @BookTypeId = scope_identity()
end
go

create procedure proc_addReaderType
    @ReaderTypeId int output,
    @ReaderTypeName nvarchar(50)
as
begin
    insert into ReaderType (ReaderTypeName) values (@ReaderTypeName)
    set @ReaderTypeId = scope_identity()
end
go

create procedure proc_AddReader
    @ReaderId nvarchar(50),
    @ReaderName nvarchar(50),
    @TimeIn datetime,
    @TimeOut datetime,
    @ReaderTypeId int,
    @DepartmentId int,
    @ClassId int,
    @IdentityCard nvarchar(50),
    @Gender nvarchar(50),
    @Special nvarchar(50),
    @Phone nvarchar(50),
    @Email nvarchar(50),
    @Address nvarchar(50),
    @ReaderRemark nvarchar(50)
as
begin
    insert into Reader (ReaderId, ReaderName, TimeIn, TimeOut, ReaderTypeId, DepartmentId, ClassId, IdentityCard, Gender, Special, Phone, Email, Address, ReaderRemark)
    values (@ReaderId, @ReaderName, @TimeIn, @TimeOut, @ReaderTypeId, @DepartmentId, @ClassId, @IdentityCard, @Gender, @Special, @Phone, @Email, @Address, @ReaderRemark)
end
go

create procedure proc_BorrowBook
    @BorrowId int output,
    @BookId nvarchar(50),
    @ReaderId nvarchar(50),
    @BorrowTime datetime,
    @ReturnTime datetime,
    @Fine decimal,
    @RenewCount int,
    @BorrowRemark nvarchar(50)
as
begin
    set @ReturnTime = dateadd(month, 3, @ReturnTime)
    insert into BorrowReturn (BookId, ReaderId, BorrowTime, ReturnTime, Fine, RenewCount, BorrowRemark)
    values (@BookId, @ReaderId, @BorrowTime, @ReturnTime, @Fine, @RenewCount, @BorrowRemark)
    set @BorrowId = scope_identity()
end
go

-- ����Լ��
alter table BorrowReturn add default null for FactReturnTime
go

alter table Admin add check (len(rtrim(ltrim(LoginId))) > 4)
go

alter table Admin add check (len(rtrim(ltrim(LoginPwd))) > 4)
go

alter table Reader add check (Gender in ('', 'Ů', '��'))
go

-- �������Լ��
alter table BorrowReturn add foreign key (BookId) references BookInfo(BookId)
go

alter table BorrowReturn add foreign key (ReaderId) references Reader(ReaderId)
go

alter table Reader add foreign key (ClassId) references Class(ClassId)
go

alter table Reader add foreign key (DepartmentId) references Department(DepartmentId)
go

alter table Reader add foreign key (ReaderTypeId) references ReaderType(ReaderTypeId)
go

